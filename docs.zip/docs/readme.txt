Hi there,

I didn't get any document in english from my college, so I made the translation for myself.
The name of the college is in Portuguese, so you can check in my profile in google-melange.

the original document: ProofofEnrollment.pdf
the translation: ProofofEnrollment_translation.pdf 

Best regards,

Camila Ayres
